export interface IGeneratorOutput {
    code: string;
    map: string;
}
