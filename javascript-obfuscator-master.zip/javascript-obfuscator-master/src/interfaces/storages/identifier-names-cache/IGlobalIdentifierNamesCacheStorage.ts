import { IMapStorage } from '../IMapStorage';

// eslint-disable-next-line
export interface IGlobalIdentifierNamesCacheStorage extends IMapStorage <string, string> {}
