import { IMapStorage } from '../IMapStorage';

// eslint-disable-next-line
export interface IPropertyIdentifierNamesCacheStorage extends IMapStorage <string, string> {}
