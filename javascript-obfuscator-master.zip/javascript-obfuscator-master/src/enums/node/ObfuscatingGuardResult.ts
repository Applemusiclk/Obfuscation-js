export enum ObfuscatingGuardResult {
    ForceTransform = 'ForceTransform',
    Ignore = 'Ignore',
    Transform = 'Transform'
}
