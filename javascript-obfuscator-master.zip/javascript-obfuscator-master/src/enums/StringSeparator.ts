export enum StringSeparator {
    Comma = ',',
    Dot = '.',
    VerticalLine = '|'
}
