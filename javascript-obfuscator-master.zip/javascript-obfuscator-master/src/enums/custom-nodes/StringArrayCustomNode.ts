export enum StringArrayCustomNode {
    StringArrayCallNode = 'StringArrayCallNode',
    StringArrayScopeCallsWrapperFunctionNode = 'StringArrayScopeCallsWrapperFunctionNode',
    StringArrayScopeCallsWrapperVariableNode = 'StringArrayScopeCallsWrapperVariableNode'
}
