export enum StringArrayIndexNode {
    StringArrayHexadecimalNumberIndexNode = 'StringArrayHexadecimalNumberIndexNode',
    StringArrayHexadecimalNumericStringIndexNode = 'StringArrayHexadecimalNumericStringIndexNode'
}
