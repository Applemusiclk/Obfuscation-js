export enum CalleeDataExtractor {
    FunctionDeclarationCalleeDataExtractor = 'FunctionDeclarationCalleeDataExtractor',
    FunctionExpressionCalleeDataExtractor = 'FunctionExpressionCalleeDataExtractor',
    ObjectExpressionCalleeDataExtractor = 'ObjectExpressionCalleeDataExtractor',
}
