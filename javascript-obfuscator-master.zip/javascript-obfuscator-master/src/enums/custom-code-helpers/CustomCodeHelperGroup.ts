export enum CustomCodeHelperGroup {
    ConsoleOutput = 'ConsoleOutput',
    DebugProtection = 'DebugProtection',
    DomainLock = 'DomainLock',
    SelfDefending = 'SelfDefending',
    StringArray = 'StringArray'
}
