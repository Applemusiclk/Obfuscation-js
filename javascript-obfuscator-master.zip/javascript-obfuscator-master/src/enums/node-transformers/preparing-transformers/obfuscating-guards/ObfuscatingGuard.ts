export enum ObfuscatingGuard {
    BlackListObfuscatingGuard = 'BlackListObfuscatingGuard',
    ConditionalCommentObfuscatingGuard = 'ConditionalCommentObfuscatingGuard',
    ForceTransformStringObfuscatingGuard = 'ForceTransformStringObfuscatingGuard',
    IgnoredImportObfuscatingGuard = 'IgnoredImportObfuscatingGuard',
    ReservedStringObfuscatingGuard = 'ReservedStringObfuscatingGuard'
}
