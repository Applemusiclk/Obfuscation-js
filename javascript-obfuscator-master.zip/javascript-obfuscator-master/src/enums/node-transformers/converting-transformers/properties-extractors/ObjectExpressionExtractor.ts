export enum ObjectExpressionExtractor {
    BasePropertiesExtractor = 'BasePropertiesExtractor',
    ObjectExpressionToVariableDeclarationExtractor = 'ObjectExpressionToVariableDeclarationExtractor'
}
