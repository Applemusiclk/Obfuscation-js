export enum LoggingPrefix {
    Base = '[javascript-obfuscator]',
    CLI = '[javascript-obfuscator-cli]'
}
