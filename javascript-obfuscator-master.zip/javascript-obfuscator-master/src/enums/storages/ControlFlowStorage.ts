export enum ControlFlowStorage {
    FunctionControlFlowStorage = 'function-control-flow-storage',
    StringControlFlowStorage = 'string-control-flow-storage'
}
