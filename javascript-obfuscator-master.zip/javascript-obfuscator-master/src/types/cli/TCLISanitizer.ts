export type TCLISanitizer <T> = (value: string) => T;
