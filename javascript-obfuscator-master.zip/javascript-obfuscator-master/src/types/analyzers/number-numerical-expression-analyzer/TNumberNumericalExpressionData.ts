export type TNumberNumericalExpressionData = (number | number[])[];
