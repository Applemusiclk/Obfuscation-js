export type TVisitorDirection = 'enter' | 'leave';
