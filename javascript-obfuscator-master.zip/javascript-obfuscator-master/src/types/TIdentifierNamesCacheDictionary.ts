import { TDictionary } from './TDictionary';

export type TIdentifierNamesCacheDictionary = TDictionary<string>;
