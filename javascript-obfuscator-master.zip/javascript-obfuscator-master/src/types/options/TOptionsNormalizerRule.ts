import { IOptions } from '../../interfaces/options/IOptions';

export type TOptionsNormalizerRule = (options: IOptions) => IOptions;
