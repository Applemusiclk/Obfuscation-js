/* eslint-disable */

declare module '@javascript-obfuscator/estraverse' {
    import estraverse from 'estraverse';

    export = estraverse;
}
