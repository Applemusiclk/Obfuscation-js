import * as acorn from 'acorn';

export const ecmaVersion = <acorn.Options['ecmaVersion'] & number>13;
