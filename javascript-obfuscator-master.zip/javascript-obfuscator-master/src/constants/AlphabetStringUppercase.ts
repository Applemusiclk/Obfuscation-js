import { alphabetString } from './AlphabetString';

export const alphabetStringUppercase: string = alphabetString.toUpperCase();
