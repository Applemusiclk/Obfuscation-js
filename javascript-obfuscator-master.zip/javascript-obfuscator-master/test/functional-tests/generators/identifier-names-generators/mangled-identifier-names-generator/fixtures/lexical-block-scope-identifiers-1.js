var foo = 'abc';
function bar (bar1, bar2) {}
function baz (baz1, baz2) {}