#!/usr/bin/env node
var foo = 'abc';