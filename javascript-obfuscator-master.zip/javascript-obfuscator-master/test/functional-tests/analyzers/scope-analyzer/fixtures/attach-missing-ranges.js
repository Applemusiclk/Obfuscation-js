function foo () {}

foo();