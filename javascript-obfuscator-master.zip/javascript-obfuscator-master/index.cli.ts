"use strict";

import { JavaScriptObfuscatorCLI } from './src/JavaScriptObfuscatorCLIFacade';

module.exports = JavaScriptObfuscatorCLI;
